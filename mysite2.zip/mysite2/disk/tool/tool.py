 #coding=utf-8
from bs4 import BeautifulSoup
soup = BeautifulSoup(open('GAB_ZIP_INDEX.xml'), 'xml')
mainContent = soup.MESSAGE.DATASET.DATA.DATASET
colVal=""
rowVal=""
for childMainContent in mainContent:
    itemList = childMainContent.find_all("ITEM")
    for item in itemList:
        if item['rmk'] == u'列分隔符（缺少值时默认为制表符\\t）':
            colVal = item['val']
        elif item['rmk'] == u'行分隔符（缺少值时默认为换行符\\n）':
            rowVal = item['val']
        elif item['rmk'] == u'文件名':
            fileName = item['val']
    columList = childMainContent.find_all(chn = True)
    resultList = []
    for colum in columList:
        resultList.append(colum['chn'])


    print colVal, rowVal, fileName, resultList
    print '\n\n\n'
