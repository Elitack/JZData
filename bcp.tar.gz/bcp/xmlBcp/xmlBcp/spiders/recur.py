 #coding=utf-8

import sys
import scrapy
from scrapy.selector import Selector
from scrapy.http import HtmlResponse
import csv

class QuotesSpider(scrapy.Spider):
    name = "quotes"
    start_urls = [
        "file://127.0.0.1/home/jack/Downloads/file1/GAB_ZIP_INDEX.xml"
    ]

    def parse(self, response):
        reload(sys)
        sys.setdefaultencoding("utf-8")
        main = response.xpath("//DATASET/DATA/DATASET")[0]
        dataset = main.xpath('./DATA')[0:2]
        for data in dataset:
            item = data.xpath('./ITEM')
            col = self.valFind(item[0].extract())
            row = self.valFind(item[1].extract())
            nameData = data.xpath('./DATASET')[0]
            name = self.valFind(nameData.xpath('./DATA/ITEM')[1].extract())
            listData = data.xpath('./DATASET')[1]
            listItem = listData.xpath('./DATA/ITEM').extract()
            colList = []
            for item in listItem:
                colList.append(self.nameFind(item))
            print name, row, col ,colList


    def valFind(self,itemTmp):
        indexF = itemTmp.find('val') + 5
        indexE = itemTmp[indexF:-1].find('"')+indexF
        return itemTmp[indexF:indexE]

    def nameFind(self,itemTmp):
        indexF = itemTmp.find('eng') + 5
        indexE = itemTmp[indexF:-1].find('"')+indexF
        return itemTmp[indexF:indexE]


    def stripFile(self,oldFName,row,col,listed):
        '''''remove the space or Tab or enter in a file,and output to a new file in the same folder'''
        fp = open("/home/jack/Downloads/file1/" + oldFName,"r+")
        newFp = file('/home/jack/Desktop/test.csv',"a+")
        for i in range(0, len(listed)-1):
            newFp.write(listed[i]+',')
        newFp.write(listed[-1]+'\n')

        for eachline in fp.readlines():
            newStr = eachline.replace(col,"\n").replace(row,",").strip()
            #print "Write:",newStr
            newFp.write(newStr+'\n')
        fp.close()
        newFp.close()
